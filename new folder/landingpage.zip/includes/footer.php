<div class="text-light bg-dark p-3 text-center">
    <p>All Rights Reserved @-Designed by Shamna-2025</p>
  </div>